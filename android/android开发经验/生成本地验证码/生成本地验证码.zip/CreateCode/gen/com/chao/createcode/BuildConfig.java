/** Automatically generated file. DO NOT MODIFY */
package com.chao.createcode;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}