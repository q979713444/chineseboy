package cn.amsoft.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;


public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        //ɨ���ά��
        Button qrCodeBtn = (Button)this.findViewById(R.id.qr_code_btn);
        Button qrCodeBtn2 = (Button)this.findViewById(R.id.qr_code_btn2);
        
        
        qrCodeBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(MainActivity.this, CaptureActivity.class);
				/**ǰ������ͷ  1��ǰ��  0�Ǻ���*/
				intent.putExtra("cameraId", 0);
				/**����Ϊ0  ����Ϊ1*/
				intent.putExtra("orientation", 1);
				startActivity(intent);
			}
		});
        
       qrCodeBtn2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(MainActivity.this, CaptureActivity.class);
				intent.putExtra("cameraId", 1);
				intent.putExtra("orientation", 1);
				startActivity(intent);
			}
		});
        
    }


   
}
