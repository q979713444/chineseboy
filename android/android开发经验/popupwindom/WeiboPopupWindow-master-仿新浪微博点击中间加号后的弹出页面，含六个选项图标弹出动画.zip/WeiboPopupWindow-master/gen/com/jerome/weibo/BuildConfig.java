/** Automatically generated file. DO NOT MODIFY */
package com.jerome.weibo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}