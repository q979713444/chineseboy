CustomLoading For Android
=============

## This project is no longer being maintained

You can get and install the apk in the apkfile folder.

![Sample image](https://raw.github.com/stormzhang/CustomLoading/master/snap.jpg)

## 关于我

[见这里](http://stormzhang.github.io/about.html)

License
============

    Copyright 2014 Storm Zhang

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.

[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/stormzhang/customloading/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

