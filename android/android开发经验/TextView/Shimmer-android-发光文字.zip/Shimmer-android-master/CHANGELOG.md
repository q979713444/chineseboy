# Change Log

## Version 1.4.0 *13/02/2015*

- Cleaned up library manifest

## Version 1.3.0 *12/01/2015*

- Updated build tools

## Version 1.2.0 *24/03/2014*

- Added `ShimmerButton`
- Minor fixes

## Version 1.1.0 *10/03/2014*

- Converted static method `Shimmer.animate()` to a class object containing the properties of the animation
- Optimized `ShimmerTextView` using a single `Shader`
- Minor fixes

## Version 1.0.0 *06/03/2014*

Initial release.