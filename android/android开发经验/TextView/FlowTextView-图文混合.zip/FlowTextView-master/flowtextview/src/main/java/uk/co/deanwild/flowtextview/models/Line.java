package uk.co.deanwild.flowtextview.models;

/**
* Created by Dean on 24/06/2014.
*/
public class Line {
    public float leftBound;
    public float rightBound;
}
