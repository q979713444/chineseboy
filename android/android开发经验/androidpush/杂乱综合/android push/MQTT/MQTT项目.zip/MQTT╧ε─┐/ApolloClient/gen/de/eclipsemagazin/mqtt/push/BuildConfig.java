/** Automatically generated file. DO NOT MODIFY */
package de.eclipsemagazin.mqtt.push;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}