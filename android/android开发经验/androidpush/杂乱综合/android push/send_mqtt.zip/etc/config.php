<?php
define('MQTT_SERVER_HOST', '192.168.28.48');
define('MQTT_SERVER_POST', '1883');
?>