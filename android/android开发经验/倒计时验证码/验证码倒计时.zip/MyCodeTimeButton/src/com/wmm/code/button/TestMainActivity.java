package com.wmm.code.button;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

/**
 * 
 * @author wmm
 * @Statement �������
 */
public class TestMainActivity extends Activity implements OnClickListener {

	private MyCodeButton v;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		v = (MyCodeButton) findViewById(R.id.button1);
		v.onCreate(savedInstanceState);
		v.setTextAfter("s�����»�ȡ").setTextBefore("��ȡ��֤��").setLenght(60 * 1000);
		v.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Toast.makeText(TestMainActivity.this, "���д�������¼�...",
				Toast.LENGTH_SHORT).show();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		v.onDestroy();
		super.onDestroy();
	}
}
