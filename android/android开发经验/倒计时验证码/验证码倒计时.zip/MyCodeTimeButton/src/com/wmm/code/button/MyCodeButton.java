package com.wmm.code.button;

import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import com.wmm.code.button.app.MyApp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

/**
 * 
 * @author wmm    email��930562017@qq.com
 * @Statement ��֤�뵹��ʱ�ؼ�
 */
public class MyCodeButton extends Button implements OnClickListener {
	private long lenght = 60 * 1000;// ����ʱ����,�������Ĭ��60��
	private String textafter = "s���ٴλ�ȡ";
	private String textbefore = "��ȡ��֤��";
	private final String TIME = "time";
	private final String CTIME = "ctime";
	private OnClickListener mOnclickListener;
	private Timer t;
	private TimerTask tt;
	private long time;
	Map<String, Long> map = new HashMap<String, Long>();

	public MyCodeButton(Context context) {
		super(context);
		setOnClickListener(this);

	}

	public MyCodeButton(Context context, AttributeSet attrs) {
		super(context, attrs);
		setOnClickListener(this);
	}

	@SuppressLint("HandlerLeak")
	Handler han = new Handler() {
		public void handleMessage(android.os.Message msg) {
			MyCodeButton.this.setText(time / 1000 + textafter);
			time -= 1000;
			if (time < 0) {
				MyCodeButton.this.setEnabled(true);
				MyCodeButton.this.setText(textbefore);
				clearTimer();
			}
		};
	};

	private void initTimer() {
		time = lenght;
		t = new Timer();
		tt = new TimerTask() {

			@Override
			public void run() {
				Log.e("wmm", time / 1000 + "");
				han.sendEmptyMessage(0x01);
			}
		};
	}

	private void clearTimer() {
		if (tt != null) {
			tt.cancel();
			tt = null;
		}
		if (t != null)
			t.cancel();
		t = null;
	}

	@Override
	public void setOnClickListener(OnClickListener l) {
		if (l instanceof MyCodeButton) {
			super.setOnClickListener(l);
		} else
			this.mOnclickListener = l;
	}

	@Override
	public void onClick(View v) {
		if (mOnclickListener != null)
			mOnclickListener.onClick(v);
		initTimer();
		this.setText(time / 1000 + textafter);
		this.setEnabled(false);
		t.schedule(tt, 0, 1000);
		// t.scheduleAtFixedRate(task, delay, period);
	}

	/**
	 * ��activity��onDestroy()����ͬ��
	 */
	public void onDestroy() {
		if (MyApp.map == null)
			MyApp.map = new HashMap<String, Long>();
		MyApp.map.put(TIME, time);
		MyApp.map.put(CTIME, System.currentTimeMillis());
		clearTimer();
		Log.e("wmm", "onDestroy");
	}

	/**
	 * ��activity��onCreate()����ͬ��
	 */
	public void onCreate(Bundle bundle) {
		Log.e("wmm", MyApp.map + "");
		if (MyApp.map == null)
			return;
		if (MyApp.map.size() <= 0)// �����ʾû���ϴ�δ��ɵļ�ʱ
			return;
		long time = System.currentTimeMillis() - MyApp.map.get(CTIME)
				- MyApp.map.get(TIME);
		MyApp.map.clear();
		if (time > 0)
			return;
		else {
			initTimer();
			this.time = Math.abs(time);
			t.schedule(tt, 0, 1000);
			this.setText(time + textafter);
			this.setEnabled(false);
		}
	}

	/** * ���ü�ʱʱ����ʾ���ı� */
	public MyCodeButton setTextAfter(String text1) {
		this.textafter = text1;
		return this;
	}

	/** * ���õ��֮ǰ���ı� */
	public MyCodeButton setTextBefore(String text0) {
		this.textbefore = text0;
		this.setText(textbefore);
		return this;
	}

	/**
	 * ���õ���ʱ����
	 * 
	 * @param lenght
	 *            ʱ�� Ĭ�Ϻ���
	 * @return
	 */
	public MyCodeButton setLenght(long lenght) {
		this.lenght = lenght;
		return this;
	}
	/*

*
*/
}