package net.neevek.android.lib.paginize;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import net.neevek.android.lib.paginize.anim.PageAnimator;

import java.lang.reflect.Constructor;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * Copyright (c) 2015 neevek <i@neevek.net>
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

/**
 * PageManager manages the pages(of type Page), it swaps(push and pop) the pages
 * when requested, it uses PageAnimationManager to animate the transition when
 * swapping Pages.
 *
 * @see net.neevek.android.lib.paginize.Page
 * @see net.neevek.android.lib.paginize.anim.PageAnimator
 */
public class PageManager {
  private final String SAVE_PAGE_STACK_KEY = "_paginize_page_stack";
  private final String TAG = PageManager.class.getSimpleName();
  private final boolean DEBUG = true;

  private PageActivity mPageActivity;
  private ViewGroup mContainerView;

  // the stack to hold the pages
  private LinkedList<Page> mPageStack = new LinkedList<Page>();

  // the page on top of the stack
  private Page mCurPage;

  // the PageAnimator to use to animate transitions when swapping pages
  private PageAnimator mPageAnimator;

  public PageManager(PageActivity pageActivity, ViewGroup containerView) {
    this(pageActivity, containerView, null);
  }

  public PageManager(PageActivity pageActivity, ViewGroup containerView, PageAnimator pageAnimator) {
    mPageActivity = pageActivity;
    mContainerView = containerView;
    mPageAnimator = pageAnimator;
  }

  public void setPageAnimator(PageAnimator pageAnimator) {
    mPageAnimator = pageAnimator;
  }

  public PageAnimator getPageAnimator() {
    return mPageAnimator;
  }

  public void pushPage(Page page) {
    pushPage(page, null, false);
  }

  public void pushPage(Page page, Object arg, boolean animated) {
    pushPage(page, arg, animated, false);
  }

  public void pushPage(final Page newPage, final Object arg, boolean animated, boolean hint) {
    if (newPage == mCurPage) {
      return;
    }

    final Page oldPage = mCurPage;

    newPage.onShow(arg);

    if (oldPage != null) {
      oldPage.onCover();
      View currentFocusedView = oldPage.getContext().getCurrentFocus();
      if (currentFocusedView != null) {
        currentFocusedView.clearFocus();
      }
    }

    mCurPage = newPage;
    mPageStack.addLast(newPage);
    mContainerView.addView(newPage.getView());
    newPage.onAttached();

    if (DEBUG) {
      Log.d(TAG, String.format(">>>> pushPage, pagestack=%d, %s, arg=%s", mPageStack.size(), newPage, arg));
    }

    if (animated && mPageAnimator != null && !newPage.onPushPageAnimation(oldPage, newPage, hint)) {
      mPageAnimator.onPushPageAnimation(oldPage, newPage, hint);
    }

    int animationDuration = newPage.getAnimationDuration();
    if (animationDuration == -1 && mPageAnimator != null) {
      animationDuration = mPageAnimator.getAnimationDuration();
    }
    if (animated && animationDuration != -1) {
      newPage.postDelayed(new Runnable() {
        @Override
        public void run() {
          doFinalWorkForPushPage(oldPage, newPage, arg);
        }
      }, animationDuration);
    } else {
      doFinalWorkForPushPage(oldPage, newPage, arg);
    }
  }

  private void doFinalWorkForPushPage(Page oldPage, Page newPage, Object arg) {
    if (oldPage != null) {
      if (newPage.getType() != Page.TYPE.TYPE_DIALOG) {
        oldPage.getView().setVisibility(View.GONE);
      }

      oldPage.onCovered();
    }

    newPage.onShown(arg);
    newPage.getView().requestFocus();
  }

  public void popPage(boolean animated) {
    popPage(animated, false);
  }

  /**
   * @param animated true to animate the transition
   * @param hint     true=left, false=right
   */
  public void popPage(boolean animated, boolean hint) {
    popTopNPages(1, animated, hint);
  }

  public void popTopNPages(int n, boolean animated, boolean hint) {
    if (n <= 0 || mPageStack.size() <= 0) {
      return;
    }

    Page oldPage = mPageStack.removeLast();
    --n;    // for mPageStack.removeLast() above

    while (--n >= 0) {
      Page page = mPageStack.removeLast();
      page.onHide();
      mContainerView.removeView(page.getView());
      page.onDetached();
      page.onHidden();

      if (DEBUG) {
        Log.d(TAG, String.format(">>>> popPage, pagestack=%d, %s", mPageStack.size(), page));
      }
    }

    popPageInternal(oldPage, animated, hint);
  }

  public void popToPage(Page destPage, boolean animated) {
    popToPage(destPage, animated, false);
  }

  /**
   * "pop" operation ends if destPage is found,
   * if destPage is not found, the method call is a no-op
   *
   * @param destPage page as the destination for this pop operation
   * @param animated true to animate the transition
   * @param hint     used by the PageAnimator
   */
  public void popToPage(Page destPage, boolean animated, boolean hint) {
    if (destPage == null) {
      throw new IllegalArgumentException("cannot call popToPage() with null destPage.");
    }

    if (mPageStack.size() <= 0 || mPageStack.lastIndexOf(destPage) == -1 || mPageStack.peekLast() == destPage) {
      return;
    }

    Page oldPage = mPageStack.removeLast();

    if (DEBUG) {
      Log.d(TAG, String.format(">>>> popPage, pagestack=%d, %s", mPageStack.size(), oldPage));
    }

    while (mPageStack.size() > 1) {
      if (mPageStack.peekLast() == destPage) {
        break;
      }

      Page page = mPageStack.removeLast();
      page.onHide();
      mContainerView.removeView(page.getView());
      page.onDetached();
      page.onHidden();
    }

    popPageInternal(oldPage, animated, hint);
  }

  public void popToClass(Class<? extends Page> pageClass, boolean animated) {
    popToClass(pageClass, animated, false);
  }

  /**
   * "pop" operation ends if the pageClass is found,
   * if the class is not found, the method call is a no-op
   *
   * @param pageClass class of page as the destination for this pop operation
   * @param animated  true to animate the transition
   * @param hint      used by the PageAnimator
   */
  public void popToClass(Class<? extends Page> pageClass, boolean animated, boolean hint) {
    if (pageClass == null) {
      throw new IllegalArgumentException("cannot call popToClass() with null pageClass.");
    }

    popToClasses(new Class[]{pageClass}, animated, hint);
  }

  public void popToClasses(Class<? extends Page>[] pageClasses, boolean animated) {
    popToClasses(pageClasses, animated, false);
  }

  /**
   * "pop" operation ends when one of the classes specified by pageClasses is found,
   * if none of the classes is found, the method call is a no-op
   *
   * @param pageClasses classes of pages as the destination for this pop operation
   * @param animated    true to animate the transition
   * @param hint        used by the PageAnimator
   */
  public void popToClasses(Class<? extends Page>[] pageClasses, boolean animated, boolean hint) {
    if (pageClasses == null || pageClasses.length == 0) {
      throw new IllegalArgumentException("cannot call popToClasses() with null or empty pageClasses.");
    }

    if (mPageStack.size() <= 0) {
      return;
    }

    // is topPage the page we want to navigate to? if so, we do not need to do anything
    Class topPageClass = mPageStack.peekLast().getClass();
    for (Class pageClass : pageClasses) {
      if (pageClass == topPageClass) {
        return;
      }
    }

    // the page we want to navigate to does not exist? if so, we do not need to do anything
    boolean hasDestClass = false;
    Iterator<Page> it = mPageStack.descendingIterator();

    LOOP1:
    while (it.hasNext()) {
      Class destPageClass = it.next().getClass();

      for (Class pageClass : pageClasses) {
        if (destPageClass == pageClass) {
          hasDestClass = true;
          break LOOP1;
        }
      }
    }
    if (!hasDestClass) {
      return;
    }

    Page oldPage = mPageStack.removeLast();

    LOOP2:
    while (mPageStack.size() > 1) {
      Class lastPageClass = mPageStack.peekLast().getClass();

      for (Class pageClass : pageClasses) {
        if (lastPageClass == pageClass) {
          break LOOP2;
        }
      }

      Page page = mPageStack.removeLast();
      page.onHide();
      mContainerView.removeView(page.getView());
      page.onDetached();
      page.onHidden();
    }

    popPageInternal(oldPage, animated, hint);
  }

  private void popPageInternal(final Page removedPage, boolean animated, boolean hint) {
    removedPage.onHide();
    View currentFocusedView = removedPage.getContext().getCurrentFocus();
    if (currentFocusedView != null) {
      currentFocusedView.clearFocus();
    }

    final Page prevPage;
    if (mPageStack.size() > 0) {    // this check is always necessary
      prevPage = mPageStack.getLast();
      prevPage.onUncover(removedPage.getReturnData());
      prevPage.getView().requestFocus();


      if (animated && mPageAnimator != null && !removedPage.onPopPageAnimation(removedPage, prevPage, hint)) {
        mPageAnimator.onPopPageAnimation(removedPage, prevPage, hint);
      }

      prevPage.getView().setVisibility(View.VISIBLE);
    } else {
      prevPage = null;

      if (animated && mPageAnimator != null && !removedPage.onPopPageAnimation(removedPage, null, hint)) {
        mPageAnimator.onPopPageAnimation(removedPage, null, hint);
      }
    }


    mCurPage = prevPage;

    int animationDuration = removedPage.getAnimationDuration();
    if (animationDuration == -1 && mPageAnimator != null) {
      animationDuration = mPageAnimator.getAnimationDuration();
    }
    if (animated && animationDuration != -1) {
      removedPage.postDelayed(new Runnable() {
        @Override
        public void run() {
          doFinalWorkForPopPageInternal(removedPage, prevPage);
        }
      }, animationDuration);

    } else {
      doFinalWorkForPopPageInternal(removedPage, prevPage);
    }
  }

  private void doFinalWorkForPopPageInternal(Page removedPage, Page prevPage) {
    mContainerView.removeView(removedPage.getView());
    removedPage.onDetached();
    removedPage.onHidden();

    if (prevPage != null) {
      prevPage.onUncovered(removedPage.getReturnData());
    }
  }

  public int lastIndexOfPage(Class<? extends Page> pageClass) {
    if (mPageStack.size() == 0) {
      return -1;
    }

    int index = mPageStack.size();
    Iterator<Page> it = mPageStack.descendingIterator();
    while (it.hasNext()) {
      --index;

      if (it.next().getClass() == pageClass) {
        return index;
      }
    }

    return -1;
  }

  public boolean onBackPressed() {
    if (mCurPage == null) {
      return false;
    }

    if (mCurPage.onBackPressed()) {
      return true;
    }

    // we do not pop the last page, let the activity handle this BACK-press
    if (getPageCount() > 1) {
      if (mCurPage.getType() == Page.TYPE.TYPE_DIALOG) {
        popPage(false, false);  // for pages of DIALOG type, do not apply animation.

      } else {
        popPage(true, true);
      }

      return true;
    }

    return false;
  }

  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (mCurPage != null) {
      mCurPage.onActivityResult(requestCode, resultCode, data);
    }
  }

  public void onPause() {
    if (mCurPage != null) {
      mCurPage.onPause();
    }
  }

  public void onResume() {
    if (mCurPage != null) {
      mCurPage.onResume();
    }
  }

  public void onDestroy() {
    if (mCurPage != null) {
      mCurPage.onHide();
      // we do not pop the top page, we simply call onHidden on it
      mCurPage.onHidden();
    }
  }

  public boolean onKeyDown(int keyCode, KeyEvent event) {
    if (mCurPage != null) {
      if (keyCode == KeyEvent.KEYCODE_MENU && event.getRepeatCount() == 0) {
        return mCurPage.onMenuPressed();

      } else {
        return mCurPage.onKeyDown(keyCode, event);
      }
    }
    return false;
  }

  public boolean onKeyUp(int keyCode, KeyEvent event) {
    if (mCurPage != null) {
      return mCurPage.onKeyUp(keyCode, event);
    }
    return false;
  }

  public boolean onTouchEvent(MotionEvent event) {
    if (mCurPage != null) {
      return mCurPage.onTouchEvent(event);
    }
    return false;
  }

  public void onConfigurationChanged(Configuration newConfig) {
    for (int i = 0; i < mPageStack.size(); ++i) {
      Page p = mPageStack.get(i);
      p.onConfigurationChanged(newConfig);
    }
  }

  public void onSaveInstanceState(Bundle outState) {
    String[] clazzArray = new String[mPageStack.size()];
    for (int i = 0; i < mPageStack.size(); ++i) {
      Page p = mPageStack.get(i);
      p.onSaveInstanceState(outState);

      clazzArray[i] = p.getClass().getName();
    }
    outState.putStringArray(SAVE_PAGE_STACK_KEY, clazzArray);
  }

  public void onRestoreInstanceState(Bundle savedInstanceState) {
    String[] clazzArray = savedInstanceState.getStringArray(SAVE_PAGE_STACK_KEY);
    Class clazz = null;
    try {
      for (int i = 0; i < clazzArray.length; ++i) {
        clazz = Class.forName(clazzArray[i]);
        Constructor ctor = clazz.getDeclaredConstructor(PageActivity.class);
        Page p = (Page) ctor.newInstance(mPageActivity);
        pushPage(p);

        p.onRestoreInstanceState(savedInstanceState);
      }
    } catch (NoSuchMethodException e) {
      throw new RuntimeException("No <init>(PageActivity) constructor in Page: " + clazz.getName()
          + ", which is required for page restore/recovery to work.");

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public Page getTopPage() {
    return mCurPage;
  }

  public int getPageCount() {
    return mPageStack.size();
  }

  boolean isPageKeptInStack(Page page) {
    return mPageStack.indexOf(page) != -1;
  }
}
