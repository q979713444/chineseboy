package com.prashant.adesara.volleysample.model;

public class FlickrResponsePhotos {

	FlickrResponse photos;
		
	public FlickrResponse getPhotos() {
		return photos;
	}

	public void setPhotos(FlickrResponse photos) {
		this.photos = photos;
	}

}
