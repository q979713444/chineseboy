/** Automatically generated file. DO NOT MODIFY */
package com.prashant.adesara.volleyexample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}