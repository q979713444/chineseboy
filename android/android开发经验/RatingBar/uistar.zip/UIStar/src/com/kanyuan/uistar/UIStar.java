package com.kanyuan.uistar;

import java.text.DecimalFormat;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class UIStar extends View{
	private Paint paint = new Paint();
	private Rect src = new Rect();
	private Rect dst = new Rect();
	private OnSelectedListener onSelectedListener;
	
	//属性
	private int normalIcon;
	private int selectedIcon;
	private int iconHeight;
	private int spacing;
	private int padding;
	private int paddingLeft;
	private int paddingTop;
	private int paddingRight;
	private int paddingBottom;
	//
	private int starCount = 5;//星星数量
	private float value = 0f;//分数，0到5之间
	private Bitmap normalIconBitmap;
	private Bitmap selectedIconBitmap;
	private boolean enabled;//设置是否可以评分
	
	public UIStar(Context context) {
		super(context);
	}
	public UIStar(Context context, AttributeSet attrs) {
		super(context, attrs);
		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.uistar);
		normalIcon = a.getResourceId(R.styleable.uistar_normalIcon, 0);
		selectedIcon = a.getResourceId(R.styleable.uistar_selectedIcon, 0);
		iconHeight = (int)a.getDimension(R.styleable.uistar_iconHeight, 0);
		spacing = (int)a.getDimension(R.styleable.uistar_spacing,  dip2px(this.getContext(), 10));
		
		padding = (int)a.getDimension(R.styleable.uistar_padding, 0);
		paddingLeft = (int)a.getDimension(R.styleable.uistar_paddingLeft, padding);
		paddingTop = (int)a.getDimension(R.styleable.uistar_paddingTop, padding);
		paddingRight = (int)a.getDimension(R.styleable.uistar_paddingRight, padding);
		paddingBottom = (int)a.getDimension(R.styleable.uistar_paddingBottom, padding);
		
		enabled = a.getBoolean(R.styleable.uistar_enabled, true);
	}
	@Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(measureWidth(widthMeasureSpec), measureHeight(heightMeasureSpec));
    }	
	/**
     * 计算组件宽度
     */
    private int measureWidth(int measureSpec) {
        int result;
        int specMode = MeasureSpec.getMode(measureSpec);
        int specSize = MeasureSpec.getSize(measureSpec);

        if (specMode == MeasureSpec.EXACTLY) {
            result = specSize;
        } else {
        	result = getDefaultWidth();
            if (specMode == MeasureSpec.AT_MOST) {
                result = Math.min(result, specSize);
            }
        }
        return result;
    }
    /**
     * 计算组件高度
     */
    private int measureHeight(int measureSpec) {
        int result;
        int specMode = MeasureSpec.getMode(measureSpec);
        int specSize = MeasureSpec.getSize(measureSpec);
        
        if (specMode == MeasureSpec.EXACTLY) {
            result = specSize;
        } else {
            result = getDefaultHeight();
            if (specMode == MeasureSpec.AT_MOST) {
                result = Math.min(result, specSize);
            }
        }
        return result;
    }
    /**
     * 计算默认宽度
     */
    private int getDefaultWidth(){
    	int defaultWidth = this.paddingLeft + this.paddingRight;   
    	Bitmap icon = this.getNormalIcon();
    	if(icon != null)
    		defaultWidth += icon.getWidth() * starCount;
    	defaultWidth += this.spacing * (starCount - 1);
    	return defaultWidth;
    }
    /**
     * 计算默认宽度
     */
    private int getDefaultHeight(){
		int defaultHeight = this.paddingTop + this.paddingBottom;
		Bitmap icon = this.getNormalIcon();
    	if(icon != null)
    		defaultHeight += icon.getHeight();
		return defaultHeight;
    }
    /**
     * 获得NormalIcon的Bitmap
     */
    private Bitmap getNormalIcon(){
    	if(this.normalIconBitmap != null)
    		return this.normalIconBitmap;
    	if(this.normalIcon == 0)
    		return null;
    	Bitmap bitmap = null;
    	bitmap = BitmapFactory.decodeResource(this.getResources(), this.normalIcon);
    	if(this.iconHeight != 0)
    		bitmap = resizeBitmap_height(bitmap, this.iconHeight);
    	this.normalIconBitmap = bitmap;
    	return bitmap;
    }
    /**
     * 获得SelectedIcon的Bitmap
     */
    private Bitmap getSelectedIcon(){
    	if(this.selectedIconBitmap != null)
    		return this.selectedIconBitmap;
    	if(this.selectedIcon == 0)
    		return null;
    	Bitmap bitmap = null;
    	bitmap = BitmapFactory.decodeResource(this.getResources(), this.selectedIcon);
    	if(this.iconHeight != 0)
    		bitmap = resizeBitmap_height(bitmap, this.iconHeight);
    	this.selectedIconBitmap = bitmap;
    	return bitmap;
    }
    /**
	 * 缩放图片
	 * @param bitmap
	 * @param w
	 * @return
	 */
	public static Bitmap resizeBitmap_height(Bitmap bitmap, int h) {
        if (bitmap != null) {
            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            float scaleSize = ((float) h) / height;
            Matrix matrix = new Matrix();
            matrix.postScale(scaleSize, scaleSize);
            Bitmap resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
            return resizedBitmap;
        } 
        return null;
    }
    @Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		//canvas.drawColor(0xFF00FF33);
		Bitmap icon = getNormalIcon();
		if(icon == null)
			return ;
		//画normal星星
		int left = this.paddingLeft;
		int top = this.getHeight()/2 - icon.getHeight()/2;
		for(int i = 0; i<starCount; i++){
			canvas.drawBitmap(icon, left, top, paint);
			left += this.spacing;
			left += icon.getWidth();
		}
		//画selected星星
		if(this.value == 0)
			return ;
		left = this.paddingLeft;
		icon = getSelectedIcon();
		if(icon == null)
			return ;
		int zhengshu = (int)this.value;//整数部分
		float xiaoshu = this.value - zhengshu;//小数部分
		for(int i = 0; i<zhengshu; i++){
			canvas.drawBitmap(icon, left, top, paint);
			left += this.spacing;
			left += icon.getWidth();
		}
		src.left = 0;
		src.top = 0;
		src.right = (int)(icon.getWidth() * xiaoshu);
		src.bottom = icon.getHeight();
		dst.left = left;
		dst.top = top;
		dst.right = left + src.width();
		dst.bottom = top + src.height();
		canvas.drawBitmap(icon, src, dst, paint);

    }
    /** 
     * 根据手机的分辨率从 dp 的单位 转成为 px(像素) 
     */  
    public static int dip2px(Context context, float dpValue) {  
        final float scale = context.getResources().getDisplayMetrics().density;  
        return (int) (dpValue * scale + 0.5f);  
    }  
    /**
	 * 触碰事件
	 */
	@Override
    public boolean onTouchEvent(MotionEvent event) {    	
		if(!this.enabled)
			return false;
		try {
			if(event.getAction() == MotionEvent.ACTION_DOWN){
				downEventHandler((int)event.getX());
		    }else if(event.getAction() == MotionEvent.ACTION_MOVE){
		    	moveEventHandler((int)event.getX());
		    }else if(event.getAction() == MotionEvent.ACTION_UP){
		    	upEventHandler((int)event.getX());
		    }
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
    }
	/**
	 * 按下事件
	 */
	private void downEventHandler(int x){
		this.value = toValue(x);
		this.invalidate();
	}
	/**
	 * 移动事件
	 */
	private void moveEventHandler(int x){
		this.value = toValue(x);
		this.invalidate();
	}
	/**
	 * 抬起事件
	 */
	private void upEventHandler(int x){
		this.value = toValue(x);
		this.invalidate();
		if(this.onSelectedListener != null){
			float value = 0;
			DecimalFormat df = new DecimalFormat("0.#");
			String s = df.format(this.value);
			this.onSelectedListener.onSelected(this, Float.parseFloat(s));
		}
	}
	/**
	 * 将坐标转为value值
	 */
	private float toValue(int x){
		Bitmap icon = getNormalIcon();
		int totalWidth = icon.getWidth() * starCount + this.spacing * (starCount - 1);
		int left = this.getWidth()/2 - totalWidth/2;
		if(x <= left)
			return 0f;
		float value = 0f;
		for(int i = 1; i<=starCount; i++){
			int right = left+icon.getWidth();
			if(x >= left && x < right){
				value = i - 1 + (x - left)/1.0f/icon.getWidth();
				break;
			}
			if(x >= right && x < right+this.spacing){
				value = i;
				break;
			}else{
				value = i;
				left = right + this.spacing;
			}			
		}
		if(value > this.starCount)
			value = this.starCount;
		return value;
	}
	/**
	 * 定义监听器
	 * @author pc
	 *
	 */
	public interface OnSelectedListener {
		public void onSelected(View view, float value);
	}
	public int getSpacing() {
		return spacing;
	}
	public void setSpacing(int spacing) {
		this.spacing = spacing;
		this.invalidate();
	}
	public int getPadding() {
		return padding;
	}
	public void setPadding(int padding) {
		this.padding = padding;
		this.paddingLeft = padding;
		this.paddingTop = padding;
		this.paddingRight = padding;
		this.paddingBottom = padding;
		this.invalidate();
	}
	public int getPaddingLeft() {
		return paddingLeft;
	}
	public void setPaddingLeft(int paddingLeft) {
		this.paddingLeft = paddingLeft;
		this.invalidate();
	}
	public int getPaddingTop() {
		return paddingTop;
	}
	public void setPaddingTop(int paddingTop) {
		this.paddingTop = paddingTop;
		this.invalidate();
	}
	public int getPaddingRight() {
		return paddingRight;
	}
	public void setPaddingRight(int paddingRight) {
		this.paddingRight = paddingRight;
		this.invalidate();
	}
	public int getPaddingBottom() {
		return paddingBottom;
	}
	public void setPaddingBottom(int paddingBottom) {
		this.paddingBottom = paddingBottom;
		this.invalidate();
	}
	public float getValue() {
		return value;
	}
	public void setValue(float value) {
		if(value > this.starCount)
			value = this.starCount;
		this.value = value;
		this.invalidate();
	}
	public void setOnSelectedListener(OnSelectedListener onSelectedListener) {
		this.onSelectedListener = onSelectedListener;
	}
	public void setNormalIcon(int normalIcon) {
		this.normalIcon = normalIcon;
	}
	public void setSelectedIcon(int selectedIcon) {
		this.selectedIcon = selectedIcon;
	}
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
}
