package com.kanyuan;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Toast;

import com.kanyuan.uistar.R;
import com.kanyuan.uistar.UIStar;
import com.kanyuan.uistar.UIStar.OnSelectedListener;

public class MainActivity extends Activity {
    private UIStar uiStar;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.main);
		
		uiStar = (UIStar)this.findViewById(R.id.uiStar);
		//uiStar.setValue(3.5f);//设置初始值
		//uiStar.setEnabled(false);
		uiStar.setOnSelectedListener(new OnSelectedListener(){
			@Override
			public void onSelected(View view, float value) {
				//弹出提示框
				Toast toast = Toast.makeText(MainActivity.this, value+"", Toast.LENGTH_SHORT);
				toast.setGravity(Gravity.BOTTOM, 0, 80);
				toast.show();
			}			
		});
	}

}
