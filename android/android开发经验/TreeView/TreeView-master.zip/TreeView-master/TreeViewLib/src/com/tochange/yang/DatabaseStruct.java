package com.tochange.yang;

class DatabaseStruct
{
    public String dbPath;

    public String tableName;

    public String fieldID;

    public String fieldIDParent;

    public String fieldName;

    public String fieldRemark;

    public int rootFieldID;
}