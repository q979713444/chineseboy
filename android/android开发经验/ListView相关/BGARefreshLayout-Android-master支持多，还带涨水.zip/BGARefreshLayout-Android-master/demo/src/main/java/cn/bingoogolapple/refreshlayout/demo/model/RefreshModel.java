package cn.bingoogolapple.refreshlayout.demo.model;

/**
 * 作者:王浩 邮件:bingoogolapple@gmail.com
 * 创建时间:15/5/21 14:53
 * 描述:
 */
public class RefreshModel {
    public String mTitle;
    public String mDetail;

    public RefreshModel(String title, String detail) {
        mTitle = title;
        mDetail = detail;
    }
}