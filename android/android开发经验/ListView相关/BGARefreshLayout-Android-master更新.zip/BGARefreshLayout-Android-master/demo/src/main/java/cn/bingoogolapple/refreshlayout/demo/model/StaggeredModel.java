package cn.bingoogolapple.refreshlayout.demo.model;

/**
 * 作者:王浩 邮件:bingoogolapple@gmail.com
 * 创建时间:15/7/9 16:12
 * 描述:
 */
public class StaggeredModel {
    public String icon;
    public String desc;
}