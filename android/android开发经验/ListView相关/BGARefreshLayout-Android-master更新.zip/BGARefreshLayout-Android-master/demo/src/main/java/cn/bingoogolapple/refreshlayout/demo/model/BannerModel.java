package cn.bingoogolapple.refreshlayout.demo.model;

import java.util.List;

/**
 * 作者:王浩 邮件:bingoogolapple@gmail.com
 * 创建时间:15/6/21 下午11:16
 * 描述:
 */
public class BannerModel {
    public List<String> imgs;
    public List<String> tips;
}